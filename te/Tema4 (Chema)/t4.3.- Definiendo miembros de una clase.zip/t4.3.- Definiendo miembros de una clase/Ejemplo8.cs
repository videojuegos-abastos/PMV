﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;
using static System.Convert;


    public class MyBaseClass
    {
        public virtual void DoSomething() => WriteLine("Base imp");
    }

    public class MyDerivedClass : MyBaseClass
    {
        public override void DoSomething()
        {
            base.DoSomething();
            WriteLine("Derived imp");
        }
    }

    class Ejemplo8
    {
        static void Main(string[] args)
        {
            MyDerivedClass myObj = new MyDerivedClass();
            MyBaseClass myBaseObj;

            myBaseObj = myObj;
            myObj.DoSomething();
            myBaseObj.DoSomething();

            ReadKey();
        }
    }
