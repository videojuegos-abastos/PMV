﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;
using static System.Convert;


    // /*
    public interface IMyInterface
    {
        void DoSomething();
        void DoSomethingElse();
    }

    public class MyClass : IMyInterface
    {
        public void DoSomething() { }
        public void DoSomethingElse() { }
    }
    // */
     /*

        // Implementación del interfaz de forma implicita y explicita
        // En este caso no funcionaria el acceso desde una variable de clase

    public class MyClass : IMyInterface
    {
    	void IMyInterface.DoSomething() {}
    	public void DoSomethingElse() {}
    }
    
    */

    class Ejemplo12
    {
        static void Main(string[] args)
        {
            MyClass myObj = new MyClass();
            myObj.DoSomething();

            MyClass myObj2 = new MyClass();
            IMyInterface myInt = myObj2;
            myInt.DoSomething();

            WriteLine("Todo Ok");
            ReadKey();
        }
    }
}
