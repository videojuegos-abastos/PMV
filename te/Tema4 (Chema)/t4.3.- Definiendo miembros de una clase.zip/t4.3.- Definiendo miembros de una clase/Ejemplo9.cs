﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;
using static System.Convert;


    public class MyBaseClass
    {
        public int entero = 5;
        public void doSomething()
        {

            MyTargetClass myObj = new MyTargetClass();
            myObj.DoSomethingWith(this);
        }
    }

    public class MyTargetClass
    {
        public void DoSomethingWith(MyBaseClass myBaseObj)
        {
            WriteLine($"El entero es {myBaseObj.entero}");
        }
    }

    class Ejemplo9
    {
        static void Main(string[] args)
        {
            MyBaseClass myBaseObj = new MyBaseClass();
            myBaseObj.doSomething();

            ReadKey();
        }
    }
