﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;
using static System.Convert;


    // /*
    public class MyBaseClass
    {
        public virtual void DoSomething() => WriteLine("Base imp");
    }

    public class MyDerivedClass : MyBaseClass
    {
        public override void DoSomething() => WriteLine("Derived imp");
    }

    // */
     /*
     
    // Si las sobrescribimos sin override el comportamiento es distinto...

    public class MyBaseClass
    {
        public virtual void DoSomething() => WriteLine("Base imp");
    }

    public class MyDerivedClass : MyBaseClass
    {
        new public void DoSomething() => WriteLine("Derived imp");
    }

     */

    class Ejemplo7
    {
        static void Main(string[] args)
        {
            MyDerivedClass myObj = new MyDerivedClass();
            MyBaseClass myBaseObj;
            myBaseObj = myObj;

            myObj.DoSomething();
            myBaseObj.DoSomething();

            ReadKey();
        }
    }

