﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;
using static System.Convert;


    public class ClassA
    {
        private int state = -1;

        public int State
        {
            get { return state; }
        }

        public class ClassB
        {
            public void SetPrivateState(ClassA target, int newState)
            {
                target.state = newState;
            }
        }
    }



    // This code will not compile:
    //public class ClassB
    //{
    //   public void SetPrivateState(ClassA target, int newState)
    //   {
    //      target.state = newState;
    //   }
    //}

    class Ejemplo11
    {
        static void Main(string[] args)
        {
            ClassA myObject = new ClassA();
            WriteLine($"myObject.State = {myObject.State}");

            ClassA.ClassB myOtherObject = new ClassA.ClassB();
            myOtherObject.SetPrivateState(myObject, 999);
            WriteLine($"myObject.State = {myObject.State}");
            ReadKey();
        }
    }