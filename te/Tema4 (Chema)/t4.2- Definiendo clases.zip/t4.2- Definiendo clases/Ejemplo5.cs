﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public class ClaseBase2
    {
        public string Propiedad4 { get; set; }
        public string Propiedad5 { get; set; }
        public int Propiedad6 { get; set; }

        public ClaseBase2() { }

        public ClaseBase2(string propiedad4, string propiedad5, int propiedad6)
        {
            Propiedad4 = propiedad4;
            Propiedad5 = propiedad5;
            Propiedad6 = propiedad6;
        }
    }

    public class ClaseBase
    {
        public string Propiedad1 { get; set; }
        public string Propiedad2 { get; set; }
        public int Propiedad3 { get; set; }
        public ClaseBase2 miClaseBase2;

        public ClaseBase() { }

        public ClaseBase(string propiedad1, string propiedad2, int propiedad3)
        {
            Propiedad1 = propiedad1;
            Propiedad2 = propiedad2;
            Propiedad3 = propiedad3;
            miClaseBase2 = new ClaseBase2("texto3", "texto4", 2);
        }

    }

    class Ejemplo5
    {
        static void Main(string[] args)
        {
            ClaseBase miClaseBase = new ClaseBase("texto1", "texto2", 1);
            ClaseBase miClaseBase2 = new ClaseBase
            {
                Propiedad1 = "texto1",
                Propiedad2 = "texto2",
                Propiedad3 = 1,
                miClaseBase2 = new ClaseBase2
                {
                    Propiedad4 = "texto3",
                    Propiedad5 = "texto4",
                    Propiedad6 = 2
                }
            };
        }
    }

