﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Edu.IesPacoMolla.Ejemplo26ClassLib;

using static System.Console;
using static System.Convert;


    class Ejemplo4
    {
        static void Main(string[] args)
        {
            MyExternalClass myObj = new MyExternalClass();
            WriteLine(myObj.ToString());
            ReadKey();

            /*
            // El siguiente código no funciona debido al modificador de acceso
            MyInternalClass myObj = new MyInternalClass();
            WriteLine(myObj.ToString());
            ReadKey();
            */
        }
    }

