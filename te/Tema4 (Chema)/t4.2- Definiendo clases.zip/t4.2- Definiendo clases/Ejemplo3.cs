﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;
using static System.Convert;


    class MyClass : ICloneable
    {
        public int val;
        public string cadena;

        public object copiar()
        {
            return MemberwiseClone();
        }

        public Object Clone()
        {
            return MemberwiseClone();
        }
    }

    struct myStruct
    {
        public int val;
        public string cadena;
    }

    class Ejemplo3
    {
        static void Main(string[] args)
        {
            MyClass objectA = new MyClass();
            //MyClass objectB = objectA;
            MyClass objectB;
            objectB = (MyClass) objectA.copiar();
            objectB = (MyClass) objectA.Clone();

            objectA.val = 10;
            objectB.val = 20;

            objectA.cadena = "Cadena1";
            objectB.cadena = "Cadena2";

            myStruct structA = new myStruct();
            myStruct structB = structA;

            structA.val = 30;
            structB.val = 40;

            structA.cadena = "Cadena1";
            structB.cadena = "Cadena2";

            WriteLine($"objectA.val = {objectA.val}");
            WriteLine($"objectB.val = {objectB.val}");
            WriteLine($"structA.val = {structA.val}");
            WriteLine($"structB.val = {structB.val}");

            WriteLine($"objectA.cadena = {objectA.cadena}");
            WriteLine($"objectB.cadena = {objectB.cadena}");
            WriteLine($"structA.cadena = {structA.cadena}");
            WriteLine($"structB.cadena = {structB.cadena}");

            ReadKey();
        }
    }
