﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;
using static System.Convert;


    public partial class MyClass
    {
        partial void DoSomethingElse();
        public void DoSomething()
        {
            WriteLine("DoSomething() execution started.");
            DoSomethingElse();
            WriteLine("DoSomething() execution finished.");
        }
    }



    public partial class MyClass
    {
        // si no implementamos este método aqui, el compilador elimina incluso la llamada a la 
        // función desde DoSomething
         partial void DoSomethingElse() => WriteLine("DoSomethingElse() called.");
    }

    class Ejemplo8
    {
        static void Main(string[] args)
        {
            MyClass myObj = new MyClass();
            myObj.DoSomething();
            ReadKey();
        }
    }