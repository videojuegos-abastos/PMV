﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static System.Console;
using static System.Convert;

    public class MyClass
    {
        private int someData=7;
        public int SomeData
        {
            get
            {
                int someData=5;
                WriteLine($"La variable someData local es {someData}");
                return this.someData;
            }
        }
    }

    class Ejemplo5
    {
        static void Main(string[] args)
        {
            MyClass miClase = new MyClass();
            Console.WriteLine($"El campo privado someData es {miClase.SomeData}");
            Console.ReadKey();
        }
    }
